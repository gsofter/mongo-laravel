<?php

namespace Jenssegers\Mongodb\Schema;

use Illuminate\Database\Schema\Grammars\Grammar as BaseGrammar;

class Grammar extends BaseGrammar
{
}
