<?php

namespace Jenssegers\Mongodb\Query;

use Illuminate\Database\Query\Processors\Processor as BaseProcessor;

class Processor extends BaseProcessor
{
}
